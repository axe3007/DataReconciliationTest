import inspect
from datetime import datetime
import pandas as pd


def tr__remove_leading_trailing_spaces(df1, df2, tr_meta=None):
    df1 = df1.applymap(lambda x: x.strip() if isinstance(x, str) else x)
    df2 = df2.applymap(lambda x: x.strip() if isinstance(x, str) else x)

    return df1, df2


def tr__keep_primary_key_matching_records(df1, df2, tr_meta=None):
    df1 = df1[df1[tr_meta["primary_keys"]].isin(df2[tr_meta["primary_keys"]]).all(axis=1)]
    df2 = df2[df2[tr_meta["primary_keys"]].isin(df1[tr_meta["primary_keys"]]).all(axis=1)]

    return df1, df2


def tr__remove_unicode_characters(df1, df2, tr_meta=None):
    df1 = df1.applymap(lambda x: x.encode(encoding='ascii', errors='ignore').decode(encoding='utf-8') if isinstance(x, str) else x)
    df2 = df2.applymap(lambda x: x.encode(encoding='ascii', errors='ignore').decode(encoding='utf-8') if isinstance(x, str) else x)

    return df1, df2


def tr__format_date(df1, df2, tr_meta=None):
    def check_and_convert_date(data):
        print(tr_meta["date_formats"])
        for dt_fmt in tr_meta["date_formats"]:
            try:
                date = datetime.strptime(data, dt_fmt["from_format"])
                return date.strftime(dt_fmt["to_format"])
            except ValueError:
                return data

    df1[pd.to_datetime(df1.apply(lambda x: pd.to_datetime(x, errors='ignore'), axis=0), errors='coerce').notna().any()]


    df1 = df1.applymap(check_and_convert_date)
    df2 = df2.applymap(check_and_convert_date)

    return df1, df2


#  23/08/2021 09:12:37  --remove seconds
#  23/08/2021 09:12     --expected

#  3/8/2021
#  03/08/2021



def tr__remove_leading_trailing_delimiters(df1, df2, tr_meta=None):
    for d in tr_meta["delimiters"]:
        df1 = df1.applymap(lambda x: x.strip(d) if isinstance(x, str) else x)
        df2 = df2.applymap(lambda x: x.strip(d) if isinstance(x, str) else x)

    return df1, df2


def tr__add_trailing_space_to_primary_key_records(df1, df2, tr_meta=None):
    for pkc in tr_meta["primary_keys"]:
        df1[pkc] = df1[pkc] + " "
        df2[pkc] = df2[pkc] + " "

    return df1, df2


def transformation_dispatcher(transformation_name):
    module = inspect.getmodule(inspect.currentframe())
    function_object = getattr(module, "tr__" + transformation_name.lower())
    return function_object
