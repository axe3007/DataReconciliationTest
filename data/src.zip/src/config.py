from utility import read_file
import json


def get_config(config_name):
    return json.loads(read_file(r"config", f"{config_name}.json"))
