from config import get_config
from transform import transformation_dispatcher
import pandas as pd

#######################################
# To be refactored
#######################################

source_file = r"data\application.csv"
target_file = r"data\archer.csv"

primary_keys = ["primary_key_column", "name"]
#######################################
# Load config
#######################################

transformations_config = get_config("transformations")
transformations_config__active_transformations = transformations_config["active_transformations"]
transformations_config__transformations = transformations_config["transformations"]

#######################################
# Main logic
#######################################

source_df = pd.read_csv(source_file, dtype=object)
target_df = pd.read_csv(target_file, dtype=object)

for transformation in transformations_config__active_transformations:
    transformation_meta = transformations_config__transformations[transformation]
    transformation_meta["primary_keys"] = primary_keys

    source_df, target_df = transformation_dispatcher(transformation)(source_df, target_df, transformation_meta)
diff = source_df.compare(target_df, result_names=("source", "target"))

for pkc in primary_keys:
    diff = diff.drop((pkc, "source"), axis=1)

diff=diff.dropna().reset_index(drop=True)

source_df.to_csv(r"data\output_source.csv", index=False)
target_df.to_csv(r"data\output_target.csv", index=False)
diff.to_csv(r"data\reconciled.csv", index=False)
