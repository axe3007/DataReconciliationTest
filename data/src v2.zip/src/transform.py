import inspect
from datetime import datetime
import pandas as pd


def tr__remove_leading_trailing_spaces(df1, df2, tr_meta=None):
    df1 = df1.applymap(lambda x: x.strip() if isinstance(x, str) else x)
    df2 = df2.applymap(lambda x: x.strip() if isinstance(x, str) else x)

    return df1, df2


def tr__keep_primary_key_matching_records(df1, df2, tr_meta=None):
    df1 = df1[df1[tr_meta["primary_keys"]].isin(df2[tr_meta["primary_keys"]]).all(axis=1)]
    df2 = df2[df2[tr_meta["primary_keys"]].isin(df1[tr_meta["primary_keys"]]).all(axis=1)]

    return df1, df2


def tr__remove_unicode_characters(df1, df2, tr_meta=None):
    df1 = df1.applymap(
        lambda x: x.encode(encoding='ascii', errors='ignore').decode(encoding='utf-8') if isinstance(x, str) else x)
    df2 = df2.applymap(
        lambda x: x.encode(encoding='ascii', errors='ignore').decode(encoding='utf-8') if isinstance(x, str) else x)

    return df1, df2


def tr__format_date(df1, df2, tr_meta=None):
    for col in df1.columns:
        if df1[col].dtype == 'object':
            try:
                df1[col] = pd.to_datetime(df1[col])
                if df1[col].dtype == 'datetime64[ns]':
                    df1[col] = df1[col].dt.strftime('%d/%m/%Y %H:%M')
            except ValueError:
                pass

    for col in df2.columns:
        if df2[col].dtype == 'object':
            try:
                df2[col] = pd.to_datetime(df2[col])
                if df2[col].dtype == 'datetime64[ns]':
                    df2[col] = df2[col].dt.strftime('%d/%m/%Y %H:%M')
            except ValueError:
                pass

    return df1, df2


def tr__remove_leading_trailing_delimiters(df1, df2, tr_meta=None):
    for d in tr_meta["delimiters"]:
        df1 = df1.applymap(lambda x: x.strip(d) if isinstance(x, str) else x)
        df2 = df2.applymap(lambda x: x.strip(d) if isinstance(x, str) else x)

    return df1, df2


def tr__add_trailing_space_to_primary_key_records_in_source(df1, df2, tr_meta=None):
    for pkc in tr_meta["primary_keys"]:
        df1[pkc] = df1[pkc] + " "

    return df1, df2


def transformation_dispatcher(transformation_name):
    module = inspect.getmodule(inspect.currentframe())
    function_object = getattr(module, "tr__" + transformation_name.lower())
    return function_object
