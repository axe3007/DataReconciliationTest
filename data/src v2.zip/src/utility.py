import os


def read_file(file_path, file_name):
    with open(os.path.join(file_path, file_name), "r", encoding="utf-8") as f:
        file_data = f.read()
        return file_data
